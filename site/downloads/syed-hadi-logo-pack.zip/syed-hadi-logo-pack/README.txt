Syed Hadi logo pack
syedcreates.com/brand

Colour: #5b3df5 to #7c5cff gradient, ink #0d0b1a.
Type: Plus Jakarta Sans 800 (name), Instrument Serif italic (tagline).
Clear space: height of the S on all sides. Minimum width 140px / 35mm. Mark alone from 24px.
Use to identify Syed Hadi in editorial, event and partner contexts.
